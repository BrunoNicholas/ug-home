@extends('layouts.site')
@section('title') User Settings @endsection

@section('styles') @endsection
@section('page_name') User Settings @endsection
@section('content')
	@include('layouts.includes.notifications')

@endsection
@section('scripts') @endsection